import React, { useState } from 'react';
import { ShoppingBag, Truck, RefreshCcw, ShieldCheck, Instagram, Facebook, MessageCircle, Star, ChevronLeft, ChevronRight } from 'lucide-react';

function App() {
  const [cartCount, setCartCount] = useState(0);
  const [currentSlide, setCurrentSlide] = useState(0);

  const products = [
    {
      id: 1,
      name: "Ultra Boost X",
      price: "$189.99",
      image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 2,
      name: "Cloud Runner",
      price: "$159.99",
      image: "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 3,
      name: "Velocity Max",
      price: "$199.99",
      image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=1000"
    }
  ];

  const collections = [
    {
      title: "Running",
      image: "https://images.unsplash.com/photo-1595341888016-a392ef81b7de?auto=format&fit=crop&q=80&w=1000"
    },
    {
      title: "Lifestyle",
      image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=1000"
    },
    {
      title: "Limited Editions",
      image: "https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?auto=format&fit=crop&q=80&w=1000"
    }
  ];

  const categories = [
    {
      title: "Sneakers",
      image: "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=1000",
      description: "Athletic & Casual Sneakers"
    },
    {
      title: "Boots",
      image: "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&q=80&w=1000",
      description: "Classic & Combat Boots"
    },
    {
      title: "Sandals",
      image: "https://images.unsplash.com/photo-1624006389438-c03488175975?auto=format&fit=crop&q=80&w=1000",
      description: "Comfort & Style Sandals"
    }
  ];

  const bestsellers = [
    {
      id: 1,
      name: "Classic Runner",
      price: "$129.99",
      image: "https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 2,
      name: "Urban Boot",
      price: "$199.99",
      image: "https://images.unsplash.com/photo-1605812860427-4024433a70fd?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 3,
      name: "Sport Elite",
      price: "$159.99",
      image: "https://images.unsplash.com/photo-1579338559194-a162d19bf842?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 4,
      name: "Street Style",
      price: "$149.99",
      image: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 5,
      name: "Urban Walker",
      price: "$139.99",
      image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 6,
      name: "City Sprinter",
      price: "$169.99",
      image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=1000"
    }
  ];

  const reviews = [
    {
      id: 1,
      name: "Sarah M.",
      rating: 5,
      text: "The most comfortable sneakers I've ever worn. Worth every penny!",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 2,
      name: "John D.",
      rating: 5,
      text: "Exceptional quality and style. These are my go-to shoes now.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=1000"
    },
    {
      id: 3,
      name: "Emily R.",
      rating: 5,
      text: "Perfect fit and amazing customer service. Highly recommend!",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=1000"
    }
  ];

  const totalSlides = Math.ceil(bestsellers.length / 3);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === totalSlides - 1 ? 0 : prev + 1));
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? totalSlides - 1 : prev - 1));
  };

  return ( 
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed w-full bg-white z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold tracking-tighter">SOLEHUB</h1>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="hover:text-gray-600 transition-colors">Home</a>
            <a href="#" className="hover:text-gray-600 transition-colors">Shop</a>
            <a href="#" className="hover:text-gray-600 transition-colors">Collections</a>
            <a href="#" className="hover:text-gray-600 transition-colors">About</a>
            <a href="#" className="hover:text-gray-600 transition-colors">Contact</a>
          </nav>

          <button className="relative">
            <ShoppingBag className="w-6 h-6" />
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-black text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen">
        <img 
          src="https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&q=80"
          alt="Hero"
          className="w-full h-full object-cover grayscale"
        />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center text-white">
            <h2 className="text-5xl md:text-7xl font-extrabold mb-4 tracking-tight">Elevate Your Stride</h2>
            <p className="text-xl md:text-2xl mb-8">Premium Footwear Engineered for Performance</p>
            <button className="bg-white text-black px-8 py-3 font-semibold hover:bg-black hover:text-white transition-colors">
              Shop New Arrivals
            </button>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-20 px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Shop by Category</h2>
        <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <div key={index} className="group relative">
              <div className="relative pb-[125%] overflow-hidden">
                <img 
                  src={category.image}
                  alt={category.title}
                  className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-30 flex flex-col items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  <h3 className="text-2xl font-bold mb-2">{category.title}</h3>
                  <p className="text-sm mb-4">{category.description}</p>
                  <button className="bg-white text-black px-6 py-2 hover:bg-black hover:text-white transition-colors">
                    Shop Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Latest Drops</h2>
        <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          {products.map((product) => (
            <div key={product.id} className="group relative">
              <div className="relative pb-[125%] overflow-hidden">
                <img 
                  src={product.image}
                  alt={product.name}
                  className="absolute inset-0 w-full h-full object-cover transition-all duration-300 group-hover:scale-105 group-hover:grayscale-0 grayscale"
                />
              </div>
              <div className="mt-4">
                <h3 className="text-lg font-semibold">{product.name}</h3>
                <p className="text-gray-700">{product.price}</p>
                <button 
                  onClick={() => setCartCount(prev => prev + 1)}
                  className="mt-2 w-full bg-black text-white py-2 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  Quick Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Bestsellers Carousel */}
      <section className="py-20 bg-gray-50">
        <h2 className="text-3xl font-bold text-center mb-12">Bestsellers</h2>
        <div className="container mx-auto px-4 relative">
          <button 
            onClick={prevSlide}
            className="absolute -left-4 top-1/2 transform -translate-y-1/2 bg-black text-white p-2 rounded-full z-10"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button 
            onClick={nextSlide}
            className="absolute -right-4 top-1/2 transform -translate-y-1/2 bg-black text-white p-2 rounded-full z-10"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-300 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {Array.from({ length: totalSlides }).map((_, slideIndex) => (
                <div key={slideIndex} className="w-full flex-shrink-0">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {bestsellers.slice(slideIndex * 3, slideIndex * 3 + 3).map((product) => (
                      <div key={product.id} className="group relative">
                        <div className="relative pb-[125%] overflow-hidden">
                          <img 
                            src={product.image}
                            alt={product.name}
                            className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-300"
                          />
                        </div>
                        <div className="mt-4 text-center">
                          <h3 className="text-xl font-semibold">{product.name}</h3>
                          <p className="text-gray-700">{product.price}</p>
                          <button 
                            onClick={() => setCartCount(prev => prev + 1)}
                            className="mt-2 w-full bg-black text-white py-2 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Collections */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
          {collections.map((collection, index) => (
            <div key={index} className="relative h-96 group overflow-hidden">
              <img 
                src={collection.image}
                alt={collection.title}
                className="w-full h-full object-cover grayscale transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                <div className="text-center">
                  <h3 className="text-white text-2xl font-bold mb-4">{collection.title}</h3>
                  <button className="bg-white text-black px-6 py-2 hover:bg-black hover:text-white transition-colors">
                    Shop Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="py-20">
        <h2 className="text-3xl font-bold text-center mb-12">What Our Customers Say</h2>
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review) => (
            <div key={review.id} className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <img 
                  src={review.image}
                  alt={review.name}
                  className="w-12 h-12 rounded-full grayscale"
                />
                <div className="ml-4">
                  <h3 className="font-semibold">{review.name}</h3>
                  <div className="flex">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current text-black" />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600">{review.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* USP Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="flex flex-col items-center">
            <Truck className="w-12 h-12 mb-4" />
            <h3 className="text-lg font-semibold">Free Shipping</h3>
            <p className="text-gray-600">On all orders over $100</p>
          </div>
          <div className="flex flex-col items-center">
            <RefreshCcw className="w-12 h-12 mb-4" />
            <h3 className="text-lg font-semibold">30-Day Returns</h3>
            <p className="text-gray-600">Hassle-free returns</p>
          </div>
          <div className="flex flex-col items-center">
            <ShieldCheck className="w-12 h-12 mb-4" />
            <h3 className="text-lg font-semibold">Secure Checkout</h3>
            <p className="text-gray-600">100% protected</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-16">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h4 className="text-lg font-bold mb-4">Contact</h4>
            <p>support@solehub.com</p>
            <p>+1 (555) 123-4567</p>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4">Customer Service</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-gray-300">Shipping Info</a></li>
              <li><a href="#" className="hover:text-gray-300">Returns</a></li>
              <li><a href="#" className="hover:text-gray-300">FAQ</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4">Follow Us</h4>
            <div className="flex space-x-4">
              <Instagram className="w-6 h-6 hover:text-gray-300 cursor-pointer" />
              <Facebook className="w-6 h-6 hover:text-gray-300 cursor-pointer" />
              <MessageCircle className="w-6 h-6 hover:text-gray-300 cursor-pointer" />
            </div>
          </div>
          <div>
            <h4 className="text-lg font-bold mb-4">Newsletter</h4>
            <div className="flex flex-col space-y-4">
              <input
                type="email"
                placeholder="Enter your email"
                className="bg-white text-black px-4 py-2"
              />
              <button className="bg-white text-black px-4 py-2 hover:bg-gray-200 transition-colors">
                Subscribe
              </button>
              <p className="text-sm text-gray-400">
                Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;