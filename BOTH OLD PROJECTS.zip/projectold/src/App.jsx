import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import ProductGrid from './components/ProductGrid';
import ShoeCarousel from './components/ShoeCarousel';
import SizeGuide from './components/SizeGuide';
import Footer from './components/Footer';
import ProductPage from './components/ProductPage';
import ProductFilters from './components/ProductFilters';
import { CartProvider } from './contexts/CartContext';
import { useState } from 'react';

function App() {
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Mock data for products
  const products = [
    {
      id: 1,
      name: 'Classic Black Sneaker',
      price: 99.99,
      image: 'https://images.unsplash.com/photo-1491553895911-0055eca6402d',
      category: 'sneakers',
      brand: 'Nike'
    },
    {
      id: 2,
      name: 'Urban Combat Boots',
      price: 149.99,
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f',
      category: 'boots',
      brand: 'Adidas'
    },
    {
      id: 3,
      name: 'Minimal Sandals',
      price: 79.99,
      image: 'https://images.unsplash.com/photo-1603487742131-4160ec999306',
      category: 'sandals',
      brand: 'Puma'
    },
    {
      id: 4,
      name: 'Running Performance',
      price: 129.99,
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff',
      category: 'sneakers',
      brand: 'New Balance'
    },
  ];

  const handleFilterChange = (filters) => {
    let filtered = [...products];

    // Apply brand filter
    if (filters.brands.length > 0) {
      filtered = filtered.filter(product => filters.brands.includes(product.brand));
    }

    // Apply category filter
    if (filters.categories.length > 0) {
      filtered = filtered.filter(product => filters.categories.includes(product.category));
    }

    // Apply price filter
    filtered = filtered.filter(product => product.price <= filters.priceRange[1]);

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredProducts(filtered);
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
    let filtered = [...products];

    if (query) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(query.toLowerCase()) ||
        product.brand.toLowerCase().includes(query.toLowerCase()) ||
        product.category.toLowerCase().includes(query.toLowerCase())
      );
    }

    setFilteredProducts(filtered);
  };

  return (
    <Router>
      <CartProvider>
        <div className="min-h-screen bg-gray-50">
          <Navbar onSearch={handleSearch} />

          <Routes>
            <Route
              path="/"
              element={
                <>
                  {/* Hero Section */}
                  <div className="relative h-[60vh] mb-12">
                    <img
                      src="https://images.unsplash.com/photo-1549298916-b41d501d3772"
                      alt="Monochrome Shoes"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                      <h1 className="text-4xl md:text-6xl text-white font-bold text-center">
                        Walk in Monochrome Elegance
                      </h1>
                    </div>
                  </div>

                  {/* Featured Categories */}
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <h2 className="text-2xl font-bold mb-8">Featured Categories</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {[
                        { name: 'Sneakers', image: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519' },
                        { name: 'Boots', image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f' },
                        { name: 'Sandals', image: 'https://images.unsplash.com/photo-1603487742131-4160ec999306' }
                      ].map((category) => (
                        <div
                          key={category.name}
                          className="relative h-64 group cursor-pointer"
                        >
                          <img
                            src={category.image}
                            alt={category.name}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-60 transition-all duration-300 flex items-center justify-center">
                            <h3 className="text-2xl text-white font-bold">{category.name}</h3>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Bestselling Products */}
                  <ShoeCarousel products={products} />

                  {/* Size Guide */}
                  <SizeGuide />

                  {/* Products with Filters */}
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex">
                    <ProductFilters onFilterChange={handleFilterChange} />
                    <div className="flex-1 pl-8">
                      <ProductGrid products={filteredProducts.length > 0 ? filteredProducts : products} />
                    </div>
                  </div>
                </>
              }
            />
            <Route path="/product/:id" element={<ProductPage products={products} />} />
          </Routes>

          <Footer />
        </div>
      </CartProvider>
    </Router>
  );
}

export default App;