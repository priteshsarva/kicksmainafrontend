import { useParams } from 'react-router-dom';
import { useState } from 'react';

export default function ProductPage({ products }) {
  const { id } = useParams();
  const product = products.find(p => p.id === parseInt(id));
  const [selectedSize, setSelectedSize] = useState('');
  
  const sizes = ['6', '7', '8', '9', '10', '11'];
  const brands = ['Nike', 'Adidas', 'Puma', 'New Balance'];
  const categories = ['sneakers', 'boots', 'sandals'];

  if (!product) {
    return <div className="text-center py-12">Product not found</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Image */}
        <div>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-[500px] object-cover"
          />
        </div>

        {/* Product Details */}
        <div>
          <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
          <p className="text-2xl mb-6">${product.price}</p>
          
          {/* Size Selection */}
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-2">Select Size</h3>
            <div className="grid grid-cols-3 gap-2">
              {sizes.map(size => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`py-2 border ${
                    selectedSize === size
                      ? 'bg-black text-white'
                      : 'bg-white text-black hover:bg-gray-100'
                  }`}
                >
                  US {size}
                </button>
              ))}
            </div>
          </div>

          {/* Add to Cart Button */}
          <button
            className="w-full bg-black text-white py-3 px-6 hover:bg-gray-800 transition-colors mb-8"
            disabled={!selectedSize}
          >
            Add to Cart
          </button>

          {/* Product Details Accordion */}
          <div className="border-t pt-6">
            <h3 className="text-lg font-medium mb-2">Product Details</h3>
            <p className="text-gray-600">
              Premium quality footwear designed for comfort and style.
              Made with high-quality materials and expert craftsmanship.
            </p>
          </div>
        </div>
      </div>

      {/* Similar Products */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6">Similar Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {products
            .filter(p => p.id !== product.id && p.category === product.category)
            .slice(0, 4)
            .map(similarProduct => (
              <div
                key={similarProduct.id}
                className="bg-white p-4 border border-gray-200 hover:bg-black group transition-all duration-300"
              >
                <img
                  src={similarProduct.image}
                  alt={similarProduct.name}
                  className="w-full h-48 object-cover"
                />
                <h3 className="mt-4 font-bold text-black group-hover:text-white">
                  {similarProduct.name}
                </h3>
                <p className="text-gray-600 group-hover:text-gray-300">
                  ${similarProduct.price}
                </p>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}