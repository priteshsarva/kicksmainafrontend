export default function SizeGuide() {
  const sizeChart = [
    { us: '6', uk: '5', eu: '38', cm: '23.5' },
    { us: '7', uk: '6', eu: '39', cm: '24.1' },
    { us: '8', uk: '7', eu: '40', cm: '24.8' },
    { us: '9', uk: '8', eu: '41', cm: '25.4' },
    { us: '10', uk: '9', eu: '42', cm: '26' },
    { us: '11', uk: '10', eu: '43', cm: '26.7' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h2 className="text-2xl font-bold mb-8">Size Guide</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                US
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                UK
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                EU
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                CM
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sizeChart.map((size, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">{size.us}</td>
                <td className="px-6 py-4 whitespace-nowrap">{size.uk}</td>
                <td className="px-6 py-4 whitespace-nowrap">{size.eu}</td>
                <td className="px-6 py-4 whitespace-nowrap">{size.cm}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-4 text-sm text-gray-600">
        Note: This size guide is approximate. For the best fit, we recommend trying on shoes before purchase.
      </p>
    </div>
  );
}