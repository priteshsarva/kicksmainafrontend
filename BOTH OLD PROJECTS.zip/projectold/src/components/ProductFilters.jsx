import { useState } from 'react';

export default function ProductFilters({ onFilterChange }) {
  const [filters, setFilters] = useState({
    brands: [],
    categories: [],
    sizes: [],
    priceRange: [0, 1000]
  });

  const brands = ['Nike', 'Adidas', 'Puma', 'New Balance'];
  const categories = ['sneakers', 'boots', 'sandals'];
  const sizes = ['6', '7', '8', '9', '10', '11'];

  const handleCheckboxChange = (type, value) => {
    const newFilters = {
      ...filters,
      [type]: filters[type].includes(value)
        ? filters[type].filter(item => item !== value)
        : [...filters[type], value]
    };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="w-64 p-4 border-r">
      {/* Brand Filter */}
      <div className="mb-6">
        <h3 className="text-lg font-medium mb-2">Brands</h3>
        {brands.map(brand => (
          <label key={brand} className="flex items-center space-x-2 mb-2">
            <input
              type="checkbox"
              checked={filters.brands.includes(brand)}
              onChange={() => handleCheckboxChange('brands', brand)}
              className="form-checkbox"
            />
            <span>{brand}</span>
          </label>
        ))}
      </div>

      {/* Category Filter */}
      <div className="mb-6">
        <h3 className="text-lg font-medium mb-2">Categories</h3>
        {categories.map(category => (
          <label key={category} className="flex items-center space-x-2 mb-2">
            <input
              type="checkbox"
              checked={filters.categories.includes(category)}
              onChange={() => handleCheckboxChange('categories', category)}
              className="form-checkbox"
            />
            <span className="capitalize">{category}</span>
          </label>
        ))}
      </div>

      {/* Size Filter */}
      <div className="mb-6">
        <h3 className="text-lg font-medium mb-2">Sizes</h3>
        <div className="grid grid-cols-3 gap-2">
          {sizes.map(size => (
            <label
              key={size}
              className={`text-center p-2 border cursor-pointer ${
                filters.sizes.includes(size)
                  ? 'bg-black text-white'
                  : 'bg-white hover:bg-gray-100'
              }`}
            >
              <input
                type="checkbox"
                checked={filters.sizes.includes(size)}
                onChange={() => handleCheckboxChange('sizes', size)}
                className="sr-only"
              />
              {size}
            </label>
          ))}
        </div>
      </div>

      {/* Price Range Filter */}
      <div>
        <h3 className="text-lg font-medium mb-2">Price Range</h3>
        <input
          type="range"
          min="0"
          max="1000"
          value={filters.priceRange[1]}
          onChange={(e) => {
            const newFilters = {
              ...filters,
              priceRange: [0, parseInt(e.target.value)]
            };
            setFilters(newFilters);
            onFilterChange(newFilters);
          }}
          className="w-full"
        />
        <div className="flex justify-between text-sm text-gray-600">
          <span>$0</span>
          <span>${filters.priceRange[1]}</span>
        </div>
      </div>
    </div>
  );
}