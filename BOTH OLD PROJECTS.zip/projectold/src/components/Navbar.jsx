import { Link } from 'react-router-dom';
import { FiShoppingCart, FiSearch, FiX } from 'react-icons/fi';
import { useCart } from '../contexts/CartContext';
import { useState, useRef, useEffect } from 'react';

export default function Navbar({ onSearch }) {
  const { cart } = useCart();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const searchRef = useRef(null);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setIsSearchOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  return (
    <div className="bg-white border-b border-gray-200">
      {/* Main Navbar */}
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center space-x-8">
            <Link to="/" className="flex-shrink-0">
              <span className="text-2xl font-bold">MONO</span>
            </Link>
            
            <div className="hidden md:block">
              <div className="flex space-x-8">
                <Link
                  to="/"
                  className="text-black hover:text-gray-600 px-3 py-2 text-sm font-medium"
                >
                  Home
                </Link>
                <Link
                  to="/men"
                  className="text-black hover:text-gray-600 px-3 py-2 text-sm font-medium"
                >
                  Men
                </Link>
                <Link
                  to="/women"
                  className="text-black hover:text-gray-600 px-3 py-2 text-sm font-medium"
                >
                  Women
                </Link>
                <Link
                  to="/new-arrivals"
                  className="text-black hover:text-gray-600 px-3 py-2 text-sm font-medium"
                >
                  New Arrivals
                </Link>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* Search Toggle Button (visible on mobile) */}
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="md:hidden p-2 hover:bg-gray-100 rounded-full"
            >
              {isSearchOpen ? (
                <FiX className="h-5 w-5" />
              ) : (
                <FiSearch className="h-5 w-5" />
              )}
            </button>

            {/* Desktop Search Bar */}
            <div className="hidden md:block relative" ref={searchRef}>
              <form onSubmit={handleSearch} className="flex items-center">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search products..."
                  className={`
                    transition-all duration-300 ease-in-out
                    ${isSearchOpen ? 'w-64' : 'w-32 focus:w-64'}
                    px-4 py-2 border border-gray-300 rounded-full
                    focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent
                  `}
                  onFocus={() => setIsSearchOpen(true)}
                />
                <button
                  type="submit"
                  className="ml-2 p-2 hover:bg-gray-100 rounded-full"
                >
                  <FiSearch className="h-5 w-5" />
                </button>
              </form>
            </div>

            {/* Cart Icon */}
            <Link to="/cart" className="relative">
              <FiShoppingCart className="h-6 w-6 text-black hover:text-gray-600" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-black text-white rounded-full h-5 w-5 flex items-center justify-center text-xs">
                  {totalItems}
                </span>
              )}
            </Link>
          </div>
        </div>
      </nav>

      {/* Mobile Search Bar (slides down when active) */}
      <div
        className={`
          md:hidden
          transition-all duration-300 ease-in-out
          overflow-hidden
          ${isSearchOpen ? 'max-h-16 py-2' : 'max-h-0 py-0'}
          border-t border-gray-200
        `}
      >
        <form onSubmit={handleSearch} className="px-4">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
            />
            <button
              type="submit"
              className="p-2 bg-black text-white rounded-full hover:bg-gray-800"
            >
              <FiSearch className="h-5 w-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}