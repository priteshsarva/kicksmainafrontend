import { useCart } from '../contexts/CartContext';
import { Link } from 'react-router-dom';

export default function ProductGrid({ products }) {
  const { addToCart } = useCart();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product) => (
        <div
          key={product.id}
          className="bg-white p-4 border border-gray-200 hover:bg-black group transition-all duration-300"
        >
          <Link to={`/product/${product.id}`}>
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-64 object-cover"
            />
            <h3 className="mt-4 font-bold text-black group-hover:text-white">
              {product.name}
            </h3>
            <p className="text-gray-600 group-hover:text-gray-300">
              ${product.price}
            </p>
          </Link>
          <button
            onClick={() => addToCart(product)}
            className="mt-2 w-full bg-black text-white px-4 py-2 group-hover:bg-white group-hover:text-black border transition-colors duration-300"
          >
            Add to Cart
          </button>
        </div>
      ))}
    </div>
  );
}