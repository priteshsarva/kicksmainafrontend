import express from 'express';
import cors from 'cors';

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

// Mock data
const products = [
  {
    id: 1,
    name: 'Classic Black Sneaker',
    price: 99.99,
    image: '/images/sneaker-bw.png',
    category: 'sneakers'
  },
  // Add more products
];

// API Routes
app.get('/api/products', (req, res) => {
  res.json(products);
});

app.get('/api/products/:category', (req, res) => {
  const { category } = req.params;
  const filteredProducts = products.filter(
    (product) => product.category === category
  );
  res.json(filteredProducts);
});

app.post('/api/newsletter', (req, res) => {
  const { email } = req.body;
  // Handle newsletter subscription (mock implementation)
  res.json({ message: 'Subscription successful' });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});